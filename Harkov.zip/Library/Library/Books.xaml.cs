﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;

namespace Library
{
    /// <summary>
    /// Логика взаимодействия для Books.xaml
    /// </summary>
    public partial class Books : Window
    {
        static DataContext db = new DataContext(Properties.Settings.Default.library);
        Table<Boooks> Book = db.GetTable<Boooks>();
        public Books()
        {
            InitializeComponent();
           
        }
        int n = 0;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            updateGrid();
        }

        private void updateGrid()// Обновление таблицы Книги
        {
            var bk = Book.Where(x => x.status == true);
            dgBooks.ItemsSource = bk;
        }

        //Кнопка добовления книги
        private void BtnAddBook_Click(object sender, RoutedEventArgs e)
        {  

            
            if (n == 0)
            {
                
                    DataContext dc = new DataContext(Properties.Settings.Default.library);
                    Boooks newuser = new Boooks
                    {
                        name = TxtBxName.Text,
                        author = TxtBxAuthor.Text,
                        kolvo = Txtkolvo.Text,
                        cost = TxtCost.Text,
                        janr = TxtJanr.Text,
                        status = true,
                    };

                    dc.GetTable<Boooks>().InsertOnSubmit(newuser);
                    dc.SubmitChanges();
                    updateGrid();
                    TxtBxName.Text = "";
                    TxtBxAuthor.Text = "";
                    Txtkolvo.Text = "";
                    TxtCost.Text = "";
                    TxtJanr.Text = "";
                

                
            }
            else
            {
                object item = dgBooks.SelectedItem;
                long vb = Convert.ToInt64((dgBooks.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
                Boooks usl = Book.FirstOrDefault(uslg => uslg.idbook.Equals(vb));
                usl.name = TxtBxName.Text;
                usl.author = TxtBxAuthor.Text;
                usl.kolvo = Txtkolvo.Text;
                usl.cost = TxtCost.Text;
                usl.janr = TxtJanr.Text;
                usl.status = true;
                var SelectQuery =
                    from a in db.GetTable<Boooks>()
                    select a;
                db.SubmitChanges();
                dgBooks.ItemsSource = SelectQuery;
                updateGrid();
                MessageBox.Show("Данные изменены");
                TxtBxName.Text = "";
                TxtBxAuthor.Text = "";
                Txtkolvo.Text = "";
                TxtCost.Text = "";
                TxtJanr.Text = "";
                n = 0;
            }
        }

        //Кнопка удаления
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            object item = dgBooks.SelectedItem;
            long vb = Convert.ToInt64((dgBooks.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

            Boooks usl = Book.FirstOrDefault(uslg => uslg.idbook.Equals(vb));

            usl.status = false;
            db.SubmitChanges();
            updateGrid();
            MessageBox.Show("Выбранная книга удалена");
        }

        //Поиск
        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchBook Search = new SearchBook();
            Search.Show();
                this.Close();
            
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            updateGrid();
        }

        private void BtnExitBook_Click(object sender, RoutedEventArgs e)
        {
            MainTable mainTable = new MainTable();
            mainTable.Show();
            this.Close();
        }

        private void BtnRedaktBook_Click(object sender, RoutedEventArgs e)
        {
            DataContext db = new DataContext(Properties.Settings.Default.library);
            Table<Boooks> classess = db.GetTable<Boooks>();
            object item = dgBooks.SelectedItem;
            long vb = Convert.ToInt64((dgBooks.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
            TxtBxAuthor.Text = (from u in classess
                              where u.idbook == vb
                              select u.author).FirstOrDefault();
            TxtBxName.Text = (from u in classess
                              where u.idbook == vb
                              select u.name).FirstOrDefault();
           TxtCost.Text = (from u in classess
                              where u.idbook == vb
                              select u.cost).FirstOrDefault();
            Txtkolvo.Text = (from u in classess
                            where u.idbook == vb
                            select u.kolvo).FirstOrDefault();
            TxtJanr.Text = (from u in classess
                             where u.idbook == vb
                             select u.janr).FirstOrDefault();
            n = 1;

        }
    }
}
