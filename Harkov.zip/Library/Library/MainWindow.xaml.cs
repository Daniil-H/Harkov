﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;


namespace Library
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnEnter_Click(object sender, RoutedEventArgs e)
        {
            string login = tbLogin.Text;
            string password = tbPassword.Text;
            string name = "";
            bool connected = false;

    
            DataContext dc = new DataContext(Properties.Settings.Default.library);
            Table<Users> users = dc.GetTable<Users>();
            foreach (var user in users)
            {
                if (user.login == tbLogin.Text)
                {
                    string role = user.post;
                    if (role == "Administrator")
                    {
                        if (user.password == tbPassword.Text)
                        {
                            //WorkWindow window2 = new WorkWindow(false, user.ID);
                            //window2.Show();
                            connected = true;
                            name = user.name;
                        }
                    }
                    else
                    {
                        if (user.password == tbPassword.Text)
                        {
                            //WorkWindow window2 = new WorkWindow(true, user.ID);
                            //window2.Show();
                            connected = true;
                            name = user.name;
                        }
                    }
                }
            }


            if (connected)
            {
                MessageBox.Show($"Вы вошли как {name}");
            }
            else
            {
                MessageBox.Show("Ошибка");
            }

            MainTable Main = new MainTable();
            Main.Show();
            Close();
        }

        private void BtnRegistory_Click(object sender, RoutedEventArgs e)
        {
            Registration reg = new Registration();
            reg.Show();
            this.Close();
        }
    }
}
