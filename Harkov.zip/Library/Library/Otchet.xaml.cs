﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Linq;
using System.Data;
                                                                
using Excel = Microsoft.Office.Interop.Excel;

namespace Library
{
    /// <summary>
    /// Логика взаимодействия для Otchet.xaml
    /// </summary>
    public partial class Otchet : Window
    {
        public Otchet()
        {
            InitializeComponent();
        }

        int otchNum;

        private void BtnOtchetOK_Click(object sender, RoutedEventArgs e)
        {
            switch (otchNum)
            {
                case 0:
                    MessageBox.Show("Выберите отчет");
                    break;
                case 1:
                    try
                    {
                        DateTime firstDate = dpOtchet1_FirstDate.SelectedDate.Value;
                        DateTime secondDate = dpOtchet1_SecondDate.SelectedDate.Value;
                                                                                                                                                                                        
                        using (DataContext dc = new DataContext(Properties.Settings.Default.library))
                        {
                            var items = dc.GetTable<Classes.Card>().Where(a => a.datetake >= firstDate && a.datetake <= secondDate && a.status != false);
                            dgOtchet.ItemsSource = items;
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Выберите даты");
                    }

                    break;
                case 2:
                    try
                    {
                        using (DataContext dc = new DataContext(Properties.Settings.Default.library))
                        {
                            Classes.Clients spec = dc.GetTable<Classes.Clients>().Where(a => a.fio == CmbBxClientsName.Text && a.status != false).ToArray()[0];
                            var items = dc.GetTable<Classes.Card>().Where(a => a.client == spec.fio && a.status != false);
                            dgOtchet.ItemsSource = items;
                        }

                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Выберите имя клиента");
                    }
                    break;

            }

        }

        private void BtnOtchetClear_Click(object sender, RoutedEventArgs e)
        {
            dpOtchet1_FirstDate.Visibility = Visibility.Collapsed;
            dpOtchet1_SecondDate.Visibility = Visibility.Collapsed;
            CmbBxClientsName.Visibility = Visibility.Collapsed;
            cbOtchet.SelectedIndex = -1;
            dgOtchet.ItemsSource = null;
            otchNum = 0;
        }

        private void BtnToExcel_Click(object sender, RoutedEventArgs e)
        {
            //Создание окна Microsoft Excel
            Excel.Application excel = new Excel.Application();
            excel.Visible = true;
            excel.WindowState = Excel.XlWindowState.xlMaximized;
            Excel.Workbook wb = excel.Workbooks.Add(System.Reflection.Missing.Value);
            Excel.Worksheet ws = wb.Sheets[1];
            //Надпись Отчет + выбранный отчет
            Excel.Range range = ws.Range["A1", "M1"];
            range.Merge(Type.Missing);
            range.Value = "Отчет " + cbOtchet.Text;
            range.Borders.Color = Excel.XlRgbColor.rgbBlack;
            range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            range.Interior.Color = Excel.XlRgbColor.rgbLightGray;

            for (int i = 0; i < dgOtchet.Columns.Count - 1; i++)
            {
                DataGridColumn dgColumn = dgOtchet.Columns[i];
                TextBlock txt = new TextBlock();
                txt.Text = dgColumn.Header.ToString();
                Excel.Range columnRange = (Excel.Range)ws.Cells[4, i + 1];
                columnRange.Value2 = txt.Text;
                columnRange.Borders.Color = Excel.XlRgbColor.rgbBlack;

                for (int j = 0; j < dgOtchet.Items.Count; j++)
                {
                    TextBlock text = dgOtchet.Columns[i].GetCellContent(dgOtchet.Items[j]) as TextBlock;

                    Excel.Range dataRange = (Excel.Range)ws.Cells[j + 5, i + 1];
                    dataRange.Value2 = text.Text;
                    dataRange.Borders.Color = Excel.XlRgbColor.rgbBlack;
                }
            }

        }

        private void CbOtchet_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (cbOtchet.SelectedIndex + 1)
            {
                case 1:
                    otchNum = 1;
                    dpOtchet1_FirstDate.Visibility = Visibility.Visible;
                    dpOtchet1_SecondDate.Visibility = Visibility.Visible;
                    CmbBxClientsName.Visibility = Visibility.Collapsed;
                    break;
                case 2:
                    otchNum = 2;
                    CmbBxClientsName.Visibility = Visibility.Visible;
                    dpOtchet1_FirstDate.Visibility = Visibility.Collapsed;
                    dpOtchet1_SecondDate.Visibility = Visibility.Collapsed;
                    using (DataContext dc = new DataContext(Properties.Settings.Default.library))
                    {
                        CmbBxClientsName.ItemsSource = dc.GetTable<Classes.Clients>().Where(a => a.status != false).Select(a => a.fio);
                    }
                    break;
            }
        }
    }

}

