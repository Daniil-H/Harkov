﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;

namespace Library
{
    /// <summary>
    /// Логика взаимодействия для Cards.xaml
    /// </summary>
    public partial class Cards : Window
    {
        static DataContext db = new DataContext(Properties.Settings.Default.library);
        Table<Classes.Card> crd = db.GetTable<Classes.Card>();
        Table<Boooks> bks = db.GetTable<Boooks>();
        Table<Classes.Clients> clts = db.GetTable<Classes.Clients>();
        Table<Classes.Workers> wrkrs = db.GetTable<Classes.Workers>();
        public Cards()
        {
            InitializeComponent();
            updateGrid();
            ComboCoxUpdate();

            if (CmbBxWorker.Text!=""&&CmbBxBook.Text!=""&&CmbBxClient.Text!=""&&DtPcDown.Text!=""&&DtPcTake.Text!="")
            {
                BtnAddWorker.IsEnabled = true;
            }
        }
        int n = 0;
        private void updateGrid()// Обновление таблицы Личная карта
        {

            var stud = crd.Where(x => x.status == true);
            dgCard.ItemsSource = stud;
        }
        public void ComboCoxUpdate()
        {

            try
            {
                var bkk = (from a in bks
                           where a.status==true
                           select a.name);
                CmbBxBook.ItemsSource = bkk;
                var clt = (from a in clts
                           where a.status == true
                           select a.fio);
                CmbBxClient.ItemsSource = clt;
                var wrk = (from a in wrkrs
                           where a.status == true
                           select a.fio);
                CmbBxWorker.ItemsSource = wrk;

            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }
        }
        private void BtnAddBook_Click(object sender, RoutedEventArgs e)
        {
            if (n == 0)
            {
                DataContext dc = new DataContext(Properties.Settings.Default.library);
                Classes.Card newuser = new Classes.Card
                {
                    worker = CmbBxWorker.Text,
                    client = CmbBxClient.Text,
                    book = CmbBxBook.Text,
                    datetake = DtPcTake.SelectedDate.Value,
                    datedelivery = DtPcDown.SelectedDate.Value,
                    status = true
                };

                dc.GetTable<Classes.Card>().InsertOnSubmit(newuser);
                dc.SubmitChanges();
                updateGrid();
                CmbBxWorker.Text = "";
                CmbBxClient.Text = "";
                CmbBxBook.Text = "";
                DtPcTake.Text = "";
                DtPcDown.Text = "";
            }
            else
            {
                object item = dgCard.SelectedItem;
                long vb = Convert.ToInt64((dgCard.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
                Classes.Card usl = crd.FirstOrDefault(uslg => uslg.idcard.Equals(vb));
                usl.worker = CmbBxWorker.Text;
                usl.client = CmbBxClient.Text;
                usl.book = CmbBxBook.Text;
                usl.datetake = DtPcTake.SelectedDate.Value;
                usl.datedelivery = DtPcDown.SelectedDate.Value;
                usl.status = true;
                var SelectQuery =
                    from a in db.GetTable<Boooks>()
                    select a;
                db.SubmitChanges();
                dgCard.ItemsSource = SelectQuery;
                updateGrid();
                MessageBox.Show("Данные изменены");
                CmbBxWorker.Text = "";
                CmbBxClient.Text = "";
                CmbBxBook.Text = "";
                DtPcTake.Text = "";
                DtPcDown.Text = "";
                n = 0;

            }

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            object item = dgCard.SelectedItem;
            long vb = Convert.ToInt64((dgCard.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

            Classes.Card usl = crd.FirstOrDefault(uslg => uslg.idcard.Equals(vb));

            usl.status = false;
            db.SubmitChanges();
            updateGrid();
            MessageBox.Show("Удалено");
        }

        private void BtnRedaktBook_Click(object sender, RoutedEventArgs e)
        {
            DataContext db = new DataContext(Properties.Settings.Default.library);
            Table<Classes.Card> classess = db.GetTable<Classes.Card>();
            object item = dgCard.SelectedItem;
            long vb = Convert.ToInt64((dgCard.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
            CmbBxBook.Text = (from u in classess
                              where u.idcard == vb
                              select u.book).FirstOrDefault();
            CmbBxClient.Text = (from u in classess
                                                        where u.idcard == vb
                                                        select u.client).FirstOrDefault();
            CmbBxWorker.Text = (from u in classess
                                                      where u.idcard == vb
                                                      select u.worker).FirstOrDefault();
            DtPcTake.Text = Convert.ToString((from u in classess
                                                  where u.idcard == vb
                                                  select u.datetake).FirstOrDefault());
            DtPcDown.Text = Convert.ToString((from u in classess
                                              where u.idcard == vb
                                              select u.datedelivery).FirstOrDefault());
            n = 1;

        }

        private void BtnExitBook_Click(object sender, RoutedEventArgs e)
        {
            MainTable mainTable = new MainTable();
            mainTable.Show();
            this.Close();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void TbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (tbSearch.Text == "")
            {
                updateGrid();
            }

            try
            {
                DataContext db = new DataContext(Properties.Settings.Default.library);
                Table<Classes.Card> st = db.GetTable<Classes.Card>();
                string[] fams = (from fam in st//заполняет массив фамилиями
                                 select fam.client).ToArray();
                string find = tbSearch.Text;
                int num = 0;
                if (tbSearch.Text != "")
                {
                    foreach (string s in fams)
                    {

                        string z = s;
                        string[] x = z.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        string c = x[0];
                        if (find != c)
                        {
                            num++;
                        }
                        if (find == c)
                        {
                            var find1 = (from f1 in st
                                         where f1.client.StartsWith(find)
                                         select f1);

                            dgCard.ItemsSource = find1;
                            num = 0;
                            break;
                        }

                    }
                    
                }
                
            }
            catch
            { 
            }

        }

        private void DgCard_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                int price;
                DataContext db = new DataContext(Properties.Settings.Default.library);
                Table<Classes.Card> classess = db.GetTable<Classes.Card>();
                object item = dgCard.SelectedItem;
                long vb = Convert.ToInt64((dgCard.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
                Classes.Card usl = crd.FirstOrDefault(uslg => uslg.idcard.Equals(vb));
                int Month = usl.datedelivery.Month - usl.datetake.Month;
                if (Month>=1)
                {
                    price = Month * 100;
                    Price p = new Price($"Задолженность - {price}");
                    LBL.Content = $"Задолженность - {price}";
                }
                else
                {
                    LBL.Content = $"Задолженность - 0";
                }
            }

            catch
            {

            }

        }
    }
}
