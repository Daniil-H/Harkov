﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Library
{
    /// <summary>
    /// Логика взаимодействия для MainTable.xaml
    /// </summary>
    public partial class MainTable : Window
    {
        public MainTable()
        {
            InitializeComponent();
        }

        private void BtnEnterBooks_Click(object sender, RoutedEventArgs e)
        {
            Books Book= new Books();
            Book.Show();
            Close();
        }

        private void BtnEnterClients_Click(object sender, RoutedEventArgs e)
        {
            Clients Client = new Clients();
            Client.Show();
            Close();

        }

        private void BtnEnterWorkers_Click(object sender, RoutedEventArgs e)
        {
            Worker Work = new Worker();
            Work.Show();
            Close();
        }

        private void BtnEnterCards_Click(object sender, RoutedEventArgs e)
        {
            Cards crd = new Cards();
            crd.Show();
            Close();

        }

        private void BtnEnterOtchet_Click(object sender, RoutedEventArgs e)
        {
           Otchet otch = new Otchet();
            otch.Show();
            Close();
        }
    }
}
