﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
namespace Library
{
    /// <summary>
    /// Логика взаимодействия для Worker.xaml
    /// </summary>
    public partial class Worker : Window
    {
        static DataContext db = new DataContext(Properties.Settings.Default.library);
        Table<Classes.Workers> Work = db.GetTable<Classes.Workers>();
        public Worker()
        {
            InitializeComponent();
            updateGrid();
        }
        int n = 0;
        private void updateGrid()// Обновление таблицы Работники
        {
            var bk = Work.Where(x => x.status == true);
            dgWorkers.ItemsSource = bk;
        }
        // добавление работника
        private void BtnAddBook_Click(object sender, RoutedEventArgs e)
        {
            if (n == 0)
            {
                DataContext dc = new DataContext(Properties.Settings.Default.library);
                Classes.Workers newuser = new Classes.Workers
                {
                    fio = TxtBxName.Text,
                    passport = TxtBxPassport.Text,
                    number = TxtBxNumber.Text,
                    status = true,
                };

                dc.GetTable<Classes.Workers>().InsertOnSubmit(newuser);
                dc.SubmitChanges();
                updateGrid();
                TxtBxName.Text = "";
                TxtBxPassport.Text = "";
                TxtBxNumber.Text = "";
            }
            //Редактирование
            else
            {
                object item = dgWorkers.SelectedItem;
                long vb = Convert.ToInt64((dgWorkers.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
                Classes.Workers usl = Work.FirstOrDefault(uslg => uslg.idworker.Equals(vb));
                usl.fio = TxtBxName.Text;
                usl.passport = TxtBxPassport.Text;
                usl.number = TxtBxNumber.Text;
                usl.status = true;
                var SelectQuery =
                    from a in db.GetTable<Boooks>()
                    select a;
                db.SubmitChanges();
                dgWorkers.ItemsSource = SelectQuery;
                updateGrid();
                MessageBox.Show("Данные изменены");
                TxtBxName.Text = "";
                TxtBxPassport.Text = "";
                TxtBxNumber.Text = "";
                n = 0;

            }
        }
        // удаление работника
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            object item = dgWorkers.SelectedItem;
            long vb = Convert.ToInt64((dgWorkers.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

            Classes.Workers usl = Work.FirstOrDefault(uslg => uslg.idworker.Equals(vb));

            usl.status = false;
            db.SubmitChanges();
            updateGrid();
            MessageBox.Show("Выбранный рабочий удален");
        }

        private void BtnRedaktBook_Click(object sender, RoutedEventArgs e)
        {
            DataContext db = new DataContext(Properties.Settings.Default.library);
            Table<Classes.Workers> classess = db.GetTable<Classes.Workers>();
            object item = dgWorkers.SelectedItem;
            long vb = Convert.ToInt64((dgWorkers.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
            TxtBxNumber.Text = (from u in classess
                                where u.idworker == vb
                                select u.number).FirstOrDefault();
            TxtBxName.Text = (from u in classess
                              where u.idworker == vb
                              select u.fio).FirstOrDefault();
            TxtBxPassport.Text = (from u in classess
                                  where u.idworker == vb
                                  select u.passport).FirstOrDefault();
            n = 1;
        }
        // выход
        private void BtnExitBook_Click(object sender, RoutedEventArgs e)
        {
            MainTable mainTable = new MainTable();
            mainTable.Show();
            this.Close();
        }
        // Поиск по фамилии
        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataContext db = new DataContext(Properties.Settings.Default.library);
                Table<Classes.Workers> st = db.GetTable<Classes.Workers>();
                string[] fams = (from fam in st//заполняет массив фамилиями
                                 select fam.fio).ToArray();
                string find = tbSearch.Text;
                int num = 0;
                if (tbSearch.Text != "")
                {
                    foreach (string s in fams)
                    {

                        string z = s;
                        string[] x = z.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        string c = x[0];
                        if (find != c)
                        {
                            num++;
                        }
                        if (find == c)
                        {
                            var find1 = (from f1 in st
                                         where f1.fio.StartsWith(find)
                                         select f1);

                            dgWorkers.ItemsSource = find1;
                            num = 0;
                            break;
                        }

                    }
                    if (dgWorkers.ItemsSource == null || num != 0)
                    {
                        MessageBox.Show("Работник не найден");
                    }
                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
                MessageBox.Show($"Введите фамилию");
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            updateGrid();
        }

        private void TbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (tbSearch.Text == "")
            {
                updateGrid();
            }
        }
    }
    
}
