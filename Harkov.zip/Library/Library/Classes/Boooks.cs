﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;

namespace Library
{
    [Table(Name = "Book")]
    public class Boooks
    {
        [Column(IsPrimaryKey = true, IsDbGenerated = true)]
        public long idbook { get; set; }
        [Column(Name = "name")]
        public string name { get; set; }
        [Column(Name = "author")]
        public string author { get; set; }
        [Column(Name = "kolvo")]
        public string kolvo { get; set; }
        [Column(Name = "cost")]
        public string cost { get; set; }
        [Column(Name = "janr")]
        public string janr { get; set; }
        [Column(Name = "status")]
        public bool status { get; set; }
    }
}

