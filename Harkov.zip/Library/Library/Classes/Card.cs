﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;

namespace Library.Classes
{
    [Table(Name = "Card")]
    public class Card
    {
        [Column(IsPrimaryKey = true, IsDbGenerated = true)]
        public long idcard { get; set; }
        [Column(Name = "worker")]
        public string worker { get; set; }
        [Column(Name = "client")]
        public string client { get; set; }
        [Column(Name = "book")]
        public string book { get; set; }
        [Column(Name = "datetake")]
        public DateTime datetake { get; set; }
        [Column(Name = "datedelivery")]
        public DateTime datedelivery { get; set; }
        [Column(Name = "status")]
        public bool status { get; set; }

        public string price { get; set; }
    }
}
