﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;

namespace Library
{
    [Table(Name = "User")]
    public class Users
    {
            [Column(IsPrimaryKey = true, IsDbGenerated = true)]
            public int id { get; set; }
            [Column(Name = "login")]
            public string login { get; set; }
            [Column(Name = "name")]
            public string name { get; set; }
            [Column(Name = "password")]
            public string password { get; set; }
            [Column(Name = "post")]
            public string post { get; set; }
            [Column(Name = "status")]
            public bool status { get; set; }
        }
}
