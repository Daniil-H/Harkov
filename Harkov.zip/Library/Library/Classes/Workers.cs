﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;

namespace Library.Classes
{

    [Table(Name = "Worker")]
    public class Workers
    {
        [Column(IsPrimaryKey = true, IsDbGenerated = true)]
        public long idworker { get; set; }
        [Column(Name = "fio")]
        public string fio { get; set; }
        [Column(Name = "passport")]
        public string passport { get; set; }
        [Column(Name = "number")]
        public string number { get; set; }
        [Column(Name = "status")]
        public bool status { get; set; }
    }
}