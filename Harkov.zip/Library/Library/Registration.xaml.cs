﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;

namespace Library
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void BtnReg_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataContext dc = new DataContext(Properties.Settings.Default.library);

                if (TxtBxfio.Text != "" && TxtBxfio.Text != "" && TxtBxPassReg.Text != "")
                {
                    Users newuser = new Users { name = TxtBxfio.Text, login = TxtBxLog.Text, password = TxtBxPassReg.Text, post = "Secretary", status = true };

                    dc.GetTable<Users>().InsertOnSubmit(newuser);
                    dc.SubmitChanges();
                }
            }
            catch
            {
                MessageBox.Show("Неверные данные");
            }
        }

        private void BtnRegClose_Click(object sender, RoutedEventArgs e)
        {
            MainWindow Auth = new MainWindow();
            Auth.Show();
            Close();
        }
    }
}
