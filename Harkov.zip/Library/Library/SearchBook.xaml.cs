﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;


namespace Library
{
    /// <summary>
    /// Логика взаимодействия для SearchBook.xaml
    /// </summary>
    public partial class SearchBook : Window
    {
        static DataContext db = new DataContext(Properties.Settings.Default.library);
        Table<Boooks> Book = db.GetTable<Boooks>();
        public SearchBook()
        {
            InitializeComponent();
            updateGrid();
        }
        private void updateGrid()// Обновление таблицы Книги
        {
            var bk = Book.Where(x => x.status == true);
            dgBooks.ItemsSource = bk;
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            updateGrid();
        }
       

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Books Book = new Books();
            Book.Show();
            Close();
        }

        private void SlValue_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            

        }


        private void TxtBxAuthor_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                DataContext db = new DataContext(Properties.Settings.Default.library);
                Table<Boooks> st = db.GetTable<Boooks>();
                string[] fams = (from fam in st//заполняет массив фамилиями
                                 select fam.author).ToArray();
                string find = TxtBxAuthor.Text;
                int num = 0;
                if (TxtBxAuthor.Text != "")
                {
                    foreach (string s in fams)
                    {

                        string z = s;
                        string[] x = z.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        string c = x[0];
                        if (find != c)
                        {
                            num++;
                        }
                        if (find == c)
                        {
                            var find1 = (from f1 in st
                                         where f1.author.StartsWith(find)
                                         select f1);

                            dgBooks.ItemsSource = find1;
                            num = 0;
                            break;
                        }


                    }
                    
                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
            }

            if (TxtBxAuthor.Text=="")
            {
                updateGrid();
            }
        }

        private void TxtBxBook_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                DataContext db = new DataContext(Properties.Settings.Default.library);
                Table<Boooks> st = db.GetTable<Boooks>();
                string[] fams = (from fam in st//заполняет массив фамилиями
                                 select fam.name).ToArray();
                string find = TxtBxBook.Text;
                int num = 0;
                if (TxtBxBook.Text != "")
                {
                    foreach (string s in fams)
                    {

                        string z = s;
                        string[] x = z.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        string c = x[0];
                        if (find != c)
                        {
                            num++;
                        }
                        if (find == c)
                        {
                            var find1 = (from f1 in st
                                         where f1.name.StartsWith(find)
                                         select f1);

                            dgBooks.ItemsSource = find1;
                            num = 0;
                            break;
                        }


                    }

                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
            }

            if (TxtBxBook.Text == "")
            {
                updateGrid();
            }
        }

        private void TxtBxJanr_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                DataContext db = new DataContext(Properties.Settings.Default.library);
                Table<Boooks> st = db.GetTable<Boooks>();
                string[] fams = (from fam in st//заполняет массив фамилиями
                                 select fam.janr).ToArray();
                string find = TxtBxJanr.Text;
                int num = 0;
                if (TxtBxJanr.Text != "")
                {
                    foreach (string s in fams)
                    {

                        string z = s;
                        string[] x = z.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        string c = x[0];
                        if (find != c)
                        {
                            num++;
                        }
                        if (find == c)
                        {
                            var find1 = (from f1 in st
                                         where f1.janr.StartsWith(find)
                                         select f1);

                            dgBooks.ItemsSource = find1;
                            num = 0;
                            break;
                        }


                    }

                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
            }

            if (TxtBxJanr.Text == "")
            {
                updateGrid();
            }

        }
    }
    }

