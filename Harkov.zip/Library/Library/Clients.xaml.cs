﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;


namespace Library
{
    /// <summary>
    /// Логика взаимодействия для Clients.xaml
    /// </summary>
    public partial class Clients : Window
    {
        static DataContext db = new DataContext(Properties.Settings.Default.library);
        Table<Classes.Clients> Client = db.GetTable<Classes.Clients>();
        public Clients()
        {
            InitializeComponent();
        }
        int n = 0;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            updateGrid();
        }
        private void updateGrid()// Обновление таблицы Клиенты
        {
            var bk = Client.Where(x => x.status == true);
            dgClients.ItemsSource = bk;
        }
        //Добавление
        private void BtnAddBook_Click(object sender, RoutedEventArgs e)
        {
            if (n == 0)
            {
                DataContext dc = new DataContext(Properties.Settings.Default.library);
                Classes.Clients newuser = new Classes.Clients
                {
                    fio = TxtBxName.Text,
                    passport=TxtBxPassport.Text,
                    number=TxtBxNumber.Text,
                    status = true,
                };

                dc.GetTable<Classes.Clients>().InsertOnSubmit(newuser);
                dc.SubmitChanges();
                updateGrid(); // Обновление таблицы
                MessageBox.Show("Клиент добавлен");
                TxtBxName.Text = "";
                TxtBxPassport.Text = "";
                TxtBxNumber.Text = "";
            }
            //Редактирование
            else
            {
                object item = dgClients.SelectedItem;
                long vb = Convert.ToInt64((dgClients.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
                Classes.Clients usl = Client.FirstOrDefault(uslg => uslg.idclient.Equals(vb));
                usl.fio = TxtBxName.Text;
                usl.passport = TxtBxPassport.Text;
                usl.number = TxtBxNumber.Text;
                usl.status = true;
                var SelectQuery =
                    from a in db.GetTable<Boooks>()
                    select a;
                db.SubmitChanges();
                dgClients.ItemsSource = SelectQuery;
                updateGrid();
                MessageBox.Show("Данные изменены");
                TxtBxName.Text = "";
                TxtBxPassport.Text = "";
                TxtBxNumber.Text = "";
                n = 0;
            }

        }

        private void BtnExitBook_Click(object sender, RoutedEventArgs e)
        {
            MainTable mainTable = new MainTable();
            mainTable.Show();
            this.Close();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            updateGrid();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            object item = dgClients.SelectedItem;
            long vb = Convert.ToInt64((dgClients.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

            Classes.Clients usl = Client.FirstOrDefault(uslg => uslg.idclient.Equals(vb));

            usl.status = false;
            db.SubmitChanges();
            updateGrid();
            MessageBox.Show("Выбранный клиент удален");
        }

        private void BtnRedaktBook_Click(object sender, RoutedEventArgs e)
        {
            DataContext db = new DataContext(Properties.Settings.Default.library);
            Table<Classes.Clients> classess = db.GetTable<Classes.Clients>();
            object item = dgClients.SelectedItem;
            long vb = Convert.ToInt64((dgClients.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
            TxtBxNumber.Text = (from u in classess
                                where u.idclient == vb
                                select u.number).FirstOrDefault();
            TxtBxName.Text = (from u in classess
                              where u.idclient == vb
                              select u.fio).FirstOrDefault();
            TxtBxPassport.Text = (from u in classess
                            where u.idclient == vb
                            select u.passport).FirstOrDefault();
            n = 1;
        }

        private void TbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                DataContext db = new DataContext(Properties.Settings.Default.library);
                Table<Classes.Clients> st = db.GetTable<Classes.Clients>();
                string[] fams = (from fam in st//заполняет массив фамилиями
                                 select fam.fio).ToArray();
                string find = tbSearch.Text;
                int num = 0;
                if (tbSearch.Text != "")
                {
                    foreach (string s in fams)
                    {

                        string z = s;
                        string[] x = z.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        string c = x[0];
                        if (find != c)
                        {
                            num++;
                        }
                        if (find == c)
                        {
                            var find1 = (from f1 in st
                                         where f1.fio.StartsWith(find)
                                         select f1);

                            dgClients.ItemsSource = find1;
                            num = 0;
                            break;
                        }

                    }
                    if (dgClients.ItemsSource == null || num != 0)
                    {
                        
                    }
                }
                else
                {
                    throw new Exception();
                }
            }
            catch
            {
               
            }

            if (tbSearch.Text=="")
            {
                updateGrid();
            }
        }
    }
}
